import { useSnackbar } from 'notistack';
import React, { useState, useRef } from 'react'
import { FaArrowLeft } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';


function ModalNewForm() {

    const navigate = useNavigate()

    const returne = () => {
        navigate(-1)
    }

    const { enqueueSnackbar } = useSnackbar()

    const [DataFields, setDataFields] = useState({});
    const [cropType, setCropType] = useState("");
    const [otherCropPlanted, setOtherCropPlanted] = useState(false);
    const [useFertilizers, setUseFertilizers] = useState(false);
    const [useCooperative, setUseCooperative] = useState(false);
    const [load, setLoad] = useState(false)
    const [message, setMessage] = useState("")
    const [file, setFile] = useState(null)

    const [photo, setPhoto] = useState(null);
    const videoRef = useRef(null);
    const canvasRef = useRef(null);

    const handleCapturePhoto = () => {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then((stream) => {
                const video = videoRef.current;
                video.srcObject = stream;
                video.play();
            })
            .catch((err) => {
                console.error('Erreur d\'accès à la caméra :', err);
            });
    };

    const handleSavePhoto = () => {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        canvas.toBlob((blob) => {
            setPhoto(blob);
            setDataFields({ ...DataFields, photo: blob });
        });

        const stream = video.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());
        video.srcObject = null;
    };


    const handleFileChange = (e) => {
        const { name, files } = e.target;
        setFile(files[0])
        setDataFields({ ...DataFields, [name]: files[0] });
    };


    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setDataFields({ ...DataFields, [name]: value });
    };

    const handleCropTypeChange = (e) => {
        const { value } = e.target;
        setCropType(value);
        setDataFields({ ...DataFields, cropType: value });
    };

    const handleOtherCropChange = (e) => {
        const { value } = e.target;
        setOtherCropPlanted(value === "Oui");
        setDataFields({ ...DataFields, otherCropPlanted: value });
    };

    const handleUseFertilizersChange = (e) => {
        const { value } = e.target;
        setUseFertilizers(value === "Oui");
        setDataFields({ ...DataFields, useFertilizers: value });
    };

    const handleUseCooperativeChange = (e) => {
        const { value } = e.target;
        setUseCooperative(value === "Oui");
        setDataFields({ ...DataFields, useCooperative: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const user = JSON.parse(localStorage.getItem("token")) || null
        let dataSeve = JSON.parse(localStorage.getItem("data")) || []
        try {
            setLoad(true)
            if (user !== null) {
                DataFields.uid = Math.floor(100000 + Math.random() * 900000)
                const form = new FormData()
                for (const key in DataFields) {
                    if (Object.prototype.hasOwnProperty.call(DataFields, key)) {
                        if (key === "photo" && DataFields[key] instanceof File) {
                            form.append(key, DataFields[key]);
                        } else {
                            form.append(key, DataFields[key]);
                        }
                    }
                }
                const api = await fetch("https://traceagri.com/fr/api/mobiledata/", {
                    headers: {
                        "Authorization": `Token ${user.token}`
                    },
                    method: "post",
                    body: form,
                });

                const res = await api.json();
                if (res && res.id !== undefined) {
                    DataFields.isSynchro = true
                    enqueueSnackbar("Donnèes sauvegardèes et synchronièes avec succès", { variant: "success" })
                } else {
                    DataFields.isSynchro = false
                    enqueueSnackbar("Donnèes sauvegardèes et en attente de synchronisation", { variant: "warning" })
                }
                if (dataSeve && dataSeve.length > 0) {
                    dataSeve.push(DataFields)
                    localStorage.setItem("data", JSON.stringify(dataSeve))
                } else {
                    localStorage.setItem("data", JSON.stringify([DataFields]))
                }
                console.log("log", DataFields)
                console.log("res", res)
                setLoad(false)
            } else {
                enqueueSnackbar("Utilisqteur non reconnu", { variant: "danger" })
                console.log("token vide")
            }
            setLoad(false)
        } catch (error) {

            DataFields.uid = Math.floor(100000 + Math.random() * 900000)
            DataFields.isSynchro = false

            if (dataSeve && dataSeve.length > 0) {
                dataSeve.push(DataFields)
                localStorage.setItem("data", JSON.stringify(dataSeve))
            } else {
                localStorage.setItem("data", JSON.stringify([DataFields]))
            }
            enqueueSnackbar("Donnèes sauvegardèes et en attente de synchronisation", { variant: "warning" })
            setLoad(false)
        }


        //console.log(DataFields);
    };

    return (
        <div className="container pt-2 mb-5">

            <div className="d-flex align-items-center justify-content-between mb-4">
                <span className='btn btn-transparent' onClick={() => returne()}><FaArrowLeft /></span>
                <h2 className='fw-bold h6 text-center pt-2'>Formulaire d'enquête</h2>
                <span></span>
            </div>

            <form className="container" onSubmit={handleSubmit}>
                <h6>Section A (Info producteur)</h6>
                <div className="mb-3">
                    <label className="small">Quel est le nom de l'agriculteur ?</label>
                    <input
                        type="text"
                        name="nom"
                        className="form-control"
                        placeholder="Entrez le nom de l'agriculteur"
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="small">Prenom</label>
                    <input
                        type="text"
                        name="prenom"
                        className="form-control"
                        placeholder="Entrez le prenom de l'agriculteur"
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="small">Quel est le contact de l'agriculteur ?</label>
                    <input
                        type="tel"
                        name="telephone"
                        className="form-control"
                        placeholder="Entrez le numéro de téléphone"
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="small">Genre</label>
                    <select
                        name="sexe"
                        className="form-select"
                        onChange={handleInputChange}

                    >
                        <option value="">Sélectionnez le genre</option>
                        <option value="M">Homme</option>
                        <option value="F">Femme</option>
                        <option value="Préfère ne pas dire">Préfère ne pas dire</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label className="small">Date de naissance</label>
                    <input
                        type="date"
                        name="date_naissance"
                        className="form-control"
                        placeholder="Entrez l'âge"
                        onChange={handleInputChange}

                    />
                </div>

                <h6>Section B (Culture principale)</h6>
                <div className="mb-3">
                    <label className="small">Type de culture</label>
                    <select
                        name="type_culture"
                        className="form-select"
                        onChange={handleCropTypeChange}

                    >
                        <option value="">Sélectionnez le type de culture</option>
                        <option value="Pérenne">Pérenne</option>
                        <option value="Saisonnière">Saisonnière</option>
                    </select>
                </div>

                {cropType === "Pérenne" && (
                    <div className="mb-3">
                        <label className="small">Quelle culture pérenne est cultivée ?</label>
                        <select
                            name="nom_culture"
                            className="form-select"
                            onChange={handleInputChange}

                        >
                            <option value="">Sélectionnez une culture</option>
                            <option value="Cacao">Cacao</option>
                            <option value="Huile de palme">Huile de palme</option>
                            <option value="Caoutchouc">Caoutchouc</option>

                        </select>
                    </div>
                )}

                {cropType === "Saisonnière" && (
                    <div className="mb-3">
                        <label className="small">Quelle culture saisonnière est cultivée ?</label>
                        <select
                            name="nom_culture"
                            className="form-select"
                            onChange={handleInputChange}

                        >
                            <option value="">Sélectionnez une culture</option>
                            <option value="Maïs">Maïs</option>
                            <option value="Riz">Riz</option>
                            <option value="Ignames">Ignames</option>
                        </select>
                    </div>
                )}

                <div className="mb-3">
                    <label className="small">En quelle année la ferme a-t-elle été établie ?</label>
                    <input
                        type="number"
                        name="annee_mise_en_place"
                        className="form-control"
                        placeholder="Entrez l'année"
                        onChange={handleInputChange}
                    />
                </div>

                <div className="mb-3">
                    <label className="small">Dimensions de la parcelle (en hectares)</label>
                    <input
                        type="number"
                        name="dimension_ha"
                        className="form-control"
                        placeholder="Entrez la dimension"
                        onChange={handleInputChange}

                    />
                </div>
                {/*
                <div className="mb-3">
                    <label className="small">Prendre une photo de la parcelle</label>
                    <button
                        type="button"
                        className="btn btn-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#exampleModal"
                        onClick={handleCapturePhoto}
                    >
                        Ouvrir la caméra
                    </button>
                    {photo && <p>Photo capturée avec succès !</p>}
                </div>
                */}

                <div className="mb-3">
                    <label className="small">Joindre une photo</label>
                    <input
                        type="file"
                        name="photo"
                        className="form-control"
                        accept="image/*"
                        capture="environment"
                        onChange={handleFileChange}

                    />
                </div>

                <h6>Section C (Culture secondaire)</h6>
                <div className="mb-3">
                    <label className="small">Avez-vous planté une autre culture au cours des 4 dernières années ?</label>
                    <select
                        name="otherCropPlanted"
                        className="form-select"
                        onChange={handleOtherCropChange}
                    >
                        <option value="">Sélectionnez</option>
                        <option value="Oui">Oui</option>
                        <option value="Non">Non</option>
                    </select>
                </div>

                {otherCropPlanted && (
                    <>
                        <div className="mb-3">
                            <label className="small">Quel type de culture avez-vous planté ?</label>
                            <select
                                name="otherCropType"
                                className="form-select"
                                onChange={handleInputChange}

                            >
                                <option value="">Sélectionnez une culture</option>
                                <option value="Maïs">Maïs</option>
                                <option value="Riz">Riz</option>
                                <option value="Cacao">Cacao</option>
                                <option value="Huile de palme">Huile de palme</option>
                                <option value="Ignames">Ignames</option>
                            </select>
                        </div>
                        <div className="mb-3">
                            <label className="small">En quelle année l'avez-vous plantée ?</label>
                            <input
                                type="number"
                                name="otherCropYear"
                                className="form-control"
                                placeholder="Entrez l'année"
                                onChange={handleInputChange}

                            />
                        </div>
                    </>
                )}

                <h6>Section D (Activitèes sur la parcelle)</h6>
                <div className="mb-3">
                    <label className="small">Utilisez-vous des engrais ?</label>
                    <select
                        name="useFertilizers"
                        className="form-select"
                        onChange={handleUseFertilizersChange}
                    >
                        <option value="">Sélectionnez</option>
                        <option value="Oui">Oui</option>
                        <option value="Non">Non</option>
                    </select>
                </div>

                {useFertilizers && (
                    <div className="mb-3">
                        <label className="small">Quel type d'engrais utilisez-vous ?</label>
                        <input
                            type="text"
                            name="fertilizerType"
                            className="form-control"
                            placeholder="Entrez le type d'engrais"
                            onChange={handleInputChange}

                        />
                    </div>
                )}


                <div className="mb-3">
                    <label className="small">Appartenez-vous à une cooperative ?</label>
                    <select
                        name="useCooperative"
                        className="form-select"
                        onChange={handleUseCooperativeChange}
                    >
                        <option value="">Sélectionnez</option>
                        <option value="Oui">Oui</option>
                        <option value="Non">Non</option>
                    </select>
                </div>

                {useCooperative && (
                    <div className="mb-3">
                        <label className="small">Nom de la cooperative</label>
                        <input
                            type="text"
                            name="nom_cooperative"
                            className="form-control"
                            placeholder="Nom de la cooperative"
                            onChange={handleInputChange}

                        />
                    </div>
                )}

                {!load ? (
                    <button type="submit" className="btn btn-success form-control">Soumettre</button>
                ) : (
                    <button className="btn btn-warning form-control" type="button" disabled>
                        <span className="spinner-border spinner-border-sm" aria-hidden="true"></span>
                        <span role="status">Traitememt en cours...</span>
                    </button>
                )}

                <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h1 className="modal-title fs-5" id="exampleModalLabel">Capturer une photo</h1>
                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                <div className="container">
                                    <video id="video" ref={videoRef} className='img-fluid' width={"100%"}></video>
                                    <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                <button
                                    type="button"
                                    className="btn btn-primary"
                                    data-bs-dismiss="modal"
                                    onClick={handleSavePhoto}
                                >
                                    Capturer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </div>

    );
}

export default ModalNewForm
