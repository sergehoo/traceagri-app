import { useSnackbar } from 'notistack';
import React, { useState, useRef, useEffect } from 'react'
import { FaArrowLeft } from "react-icons/fa";
import { Link, useNavigate } from 'react-router-dom';
import { GoPencil } from "react-icons/go";
import { LuRefreshCcw } from "react-icons/lu";

function NoSyncPage() {

    const [data, setData] = useState(null)
    const [load, setLoad] = useState(true)
    const [isNo, setIsNo] = useState(false)
    const [loadsynchro, setLoadsynchro] = useState(false)

    const navigate = useNavigate()
    const { enqueueSnackbar } = useSnackbar()

    const returne = () => {
        navigate(-1)
    }

    const synchroData = async (uid) => {
        if (data && data.length > 0 && uid !== undefined) {
            try {
                const file = data.find(item => item.uid === uid)
                setLoadsynchro(true)
                const user = JSON.parse(localStorage.getItem("token")) || null

                const form = new FormData()

                for (const key in file) {
                    if (Object.prototype.hasOwnProperty.call(file, key)) {
                        if (key === "photo" && file[key] instanceof File) {
                            form.append(key, file[key]);
                        } else {
                            form.append(key, file[key]);
                        }
                    }
                }
                const api = await fetch("https://traceagri.com/fr/api/mobiledata/", {
                    headers: {
                        "Authorization": `Token ${user.token}`
                    },
                    method: "post",
                    body: form,
                });
                const res = await api.json();
                console.log(res)
                if (res && res.id !== undefined) {
                    data.forEach((item) => {
                        if (item.uid === uid) item.isSynchro = true
                    })
                    localStorage.setItem("data", JSON.stringify(data))
                    setIsNo(true)
                    enqueueSnackbar("Donnèes sauvegardèes et synchronièes avec succès", { variant: "success" })
                } else {
                    enqueueSnackbar("Synchronisation non reussie, vèrifiez votre connection internet", { variant: "warning" })
                }
                setLoadsynchro(false)
            } catch (error) {
                console.log(error)
                enqueueSnackbar("Synchronisation non reussie, une erreure s'est produite", { variant: "warning" })
                setLoadsynchro(false)
            }
        }
    }

    useEffect(() => {
        setTimeout(() => {
            setData(JSON.parse(localStorage.getItem("data")) || [])
            const donne = JSON.parse(localStorage.getItem("data"))
            const find = donne.find(item => item.isSynchro === false) || null
            if (!find) setIsNo(true)
            setLoad(false)
        }, 1000);


    }, [])

    return (
        <div className="container pt-2 mb-5">
            <div className="d-flex align-items-center justify-content-between mb-4">
                <span className='btn btn-transparent' onClick={() => returne()}><FaArrowLeft /></span>
                <h2 className='fw-bold h6 text-center pt-2'>Donnèes non synchronisées</h2>
                <span></span>
            </div>

            <div className='row'>
                <div className="container">

                    {!load ?
                        (
                            <>
                                {data && data.length > 0 ? (
                                    <>
                                        {data && data.length && data.map(item => (
                                            <>
                                                {item.isSynchro === false && (
                                                    <div className="card p-0 shadow mb-2" key={item.uid}>
                                                        <div className="card-body d-flex justify-content-between align-items-center">
                                                            <div>
                                                                <p className='fw-bold mb-0'>{item.nom} {item.prenom}</p>
                                                                <p className='mb-0'>Tel.: {item.telephone} </p>
                                                            </div>
                                                            <div className='d-flex align-items-center'>
                                                                <p className='pt-3 me-2'>id: <strong>{item.uid}</strong></p>
                                                                {/* <Link to={`/dash/updtate/${item.uid}`} className='mx-2 btn btn-info text-light me-2'><GoPencil /></Link> */}
                                                                {loadsynchro ? (
                                                                    <button class="btn btn-warning" type="button" disabled>
                                                                        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                                                                        <span class="visually-hidden" role="status">Loading...</span>
                                                                    </button>
                                                                ) : (
                                                                    <button className='btn btn-success' onClick={() => synchroData(item.uid)}><LuRefreshCcw /></button>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}
                                            </>
                                        ))}
                                    </>
                                ) : (
                                    <p className='h4 fw-bold'>Aucune donnèe à afficher</p>
                                )}
                                {isNo && <p className='h4 fw-bold text-center'>Aucune donnèe à synchroniser</p>}
                            </>
                        )
                        : (
                            <>
                                <p className="card-text placeholder-glow">
                                    <span className="placeholder col-7"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-6"></span>
                                    <span className="placeholder col-8"></span>
                                </p>
                                <p className="card-text placeholder-glow">
                                    <span className="placeholder col-7"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-6"></span>
                                    <span className="placeholder col-8"></span>
                                </p>
                            </>
                        )
                    }

                </div>
            </div>
        </div>
    )
}

export default NoSyncPage
