import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'

function Saisie({data}) {

  return (
    <div className='col-md-12 mb-3'>
    <Link to="/dash/all" className="card text-decoration-none shadow hover-zoom">
      <div className="card-body d-flex justify-content-between align-items-center">
          <h2 className='h5'>Données saisies</h2>
            <div className='color-round rond'>
               {data && data.length > 0 ? data.length : 0}
            </div>
      </div>
    </Link>
  </div>
  )
}

export default Saisie
