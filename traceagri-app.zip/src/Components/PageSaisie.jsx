import { useSnackbar } from 'notistack';
import React, { useState, useRef, useEffect } from 'react'
import { FaArrowLeft } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
import { IoMdCloseCircleOutline } from "react-icons/io";
import { FaCheckDouble } from "react-icons/fa6";

function PageSaisie() {

    const [data, setData] = useState(null)
    const [load, setLoad] = useState(true)

    const navigate = useNavigate()
    const { enqueueSnackbar } = useSnackbar()

    const returne = () => {
        navigate(-1)
    }

    useEffect(() => {
        setTimeout(() => {
            setData(JSON.parse(localStorage.getItem("data")) || [])
            setLoad(false)
        }, 1000);
    }, [])

    return (
        <div className="container pt-2 mb-5">
            <div className="d-flex align-items-center justify-content-between mb-4">
                <span className='btn btn-transparent' onClick={() => returne()}><FaArrowLeft /></span>
                <h2 className='fw-bold h6 text-center pt-2'>Données saisies</h2>
                <span></span>
            </div>

            <div className='row'>
                <div className="container">

                    {!load ?
                        (
                            <>
                                {data && data.length > 0 ? (
                                    <>
                                        {data && data.length && data.map(item => (
                                            <>
                                                <div className="card p-0 shadow mb-2" key={item.uid}>
                                                    <div className="card-body d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <p className='fw-bold mb-0'>{item.nom} {item.prenom}</p>
                                                            <p className='mb-0'>Tel.: {item.telephone} </p>
                                                        </div>
                                                        <div className='d-flex align-items-center'>
                                                            <p className='me-2'>id: <strong>{item.uid}</strong></p>
                                                            {item.isSynchro === false ? (
                                                                <p className='text-danger'><IoMdCloseCircleOutline /></p>
                                                            ) : (
                                                                <p className='text-success'><FaCheckDouble /></p>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </>
                                        ))}
                                    </>
                                ) : (
                                    <p className='h4 fw-bold text-center'>Aucune donnèe à afficher</p>
                                )}
                            </>
                        )
                        : (
                            <>
                                <p className="card-text placeholder-glow">
                                    <span className="placeholder col-7"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-6"></span>
                                    <span className="placeholder col-8"></span>
                                </p>
                                <p className="card-text placeholder-glow">
                                    <span className="placeholder col-7"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-4"></span>
                                    <span className="placeholder col-6"></span>
                                    <span className="placeholder col-8"></span>
                                </p>
                            </>
                        )
                    }

                </div>
            </div>
        </div>
    )
}

export default PageSaisie
