import { useSnackbar } from 'notistack'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function NonSynchro({data}) {

  const [sync, setSync] = useState(0)
  useEffect(() => {
      if (data && data.length > 0) {
        let cop = 0
        data.forEach((item) => {
          if (item.isSynchro === false)  cop++
        })
        setSync(cop)
      }
  }, [])

  return (
    <div className='col-md-12 mb-3'>
      <Link to="/dash/nosync" className="card text-decoration-none shadow hover-zoom">
      <div className="card-body d-flex justify-content-between align-items-center">
          <h2 className='h5'>Données <br /> non synchronisées</h2>
            <div className='color-round rond'>
            {sync}
            </div>
      </div>
      </Link>
    </div>
  )
}

export default NonSynchro
