import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FaEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";

function Login() {
  const [username, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [load, setLoad] = useState(false)
  const [message, setMessage] = useState("")
  const [view, setView] = useState(false)

  const [user, setUser] = useState(null)
  const [loadpage, setLoadpage] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setUser(JSON.parse(localStorage.getItem("token")))
      setLoadpage(false)
    }, 100);
  }, [])

  const submitForm = async (e) => {
    e.preventDefault();
    try {
      setLoad(true)
      setMessage("")
      const api = await fetch("https://traceagri.com/fr/auth/tablette/token/login/", {
        headers: { "Content-type": "application/json" },
        method: "post",
        body: JSON.stringify({ username, password }),
      });
      const res = await api.json();
      if (res && res.auth_token && res.auth_token !== "") {
        setTimeout(() => {
          localStorage.setItem("token", JSON.stringify({
            username,
            token: res.auth_token
          }))
          document.getElementById("redirecte").click()
          return
        }, 100);
      } else {
        setMessage("Identifiant ou mot de passe incorrect")
      }
      setLoad(false)
    } catch (error) {
      setMessage("Erreur survenue, verifiez votre connection internet!")
      setLoad(false)
    }
  };

  if (!load) {
    if (user && user !== undefined) {
      location.href = "/dash"
    }
    else {
      return (
        <div
          className="login d-flex justify-content-center align-items-center"
          style={{ height: "100vh", width: "100%" }}
        >
          <Link to="/dash" id="redirecte"></Link>
          <div className="container">
            <img src="/img/logo2.png" className="img=fluid" width={"100%"} alt="" />
            <form className="row mt-4" onSubmit={(e) => submitForm(e)}>
              {message !== "" && <p className="bg-danger text-center text-white fw-bold mb-3 rounded-2">{message}</p>}
              <div className="form-floating mb-3">
                <input
                  onChange={(e) => setLogin(e.target.value)}
                  type="text"
                  className="form-control"
                  id="login"
                  placeholder="Login"
                />
                <label htmlFor="login">Login</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  onChange={(e) => setPassword(e.target.value)}
                  type={!view ? "password" : "text"}
                  className="form-control"
                  id="floatingPassword"
                  placeholder="Password"
                />
                <label htmlFor="floatingPassword">Password</label>
              </div>
              <div className="mb-3">
                <button className="btn btn-primary btn-sm" type="button" onClick={() => setView(!view)}>
                  {view ? (
                    <FaRegEyeSlash />
                  ) : (
                    <FaEye />
                  )}
                </button>
              </div>
              <div>
                {!load ? (
                  <button type="submit" className="btn btn-success form-control">Login</button>
                ) : (
                  <button className="btn btn-warning form-control" type="button" disabled>
                    <span className="spinner-border spinner-border-sm" aria-hidden="true"></span>
                    <span role="status">Loading...</span>
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      );
    }
  }
}

export default Login;
