import React, { useEffect, useState } from 'react'
import Synchroniser from '../Components/Synchroniser'
import NonSynchro from '../Components/NonSynchro'
import Saisie from '../Components/Saisie'
import { IoIosLogOut } from "react-icons/io";
import NewBtn from '../Components/NewBtn'
import { SnackbarProvider } from 'notistack';

function Dashbord() {
    const [user, setUser] = useState(null)
    const [data, setData] = useState(null)
    const [load, setLoad] = useState(true)

    const LogOut = () => {
        localStorage.removeItem("token")
        location.href = "/"
    }

    useEffect(() => {
        setTimeout(() => {
            setUser(JSON.parse(localStorage.getItem("token")))
            setData(JSON.parse(localStorage.getItem("data")) || [])
            setLoad(false)
        }, 100);
    }, [])

    if (!load) {
        if (user && user.token !== "") {
            return (
                <>
                    {user && user.username !== "" &&
                        <headr className="d-flex align-items-center px-3 justify-content-between bg-success">
                            <p className='fw-bold text-white pt-3'>{user.username}</p>
                            <button className='btn btn-light btn-sm' onClick={() => LogOut()}><IoIosLogOut /></button>
                        </headr>
                    }
                    <div className='py-5'>
                        <div className="container">
                            <h2 className='fw-bold text-center mb-4 h4'>Statistique des Données</h2>
                            <div className="row">
                                <Saisie data={data} />
                                <Synchroniser data={data} />
                                <NonSynchro data={data} />
                                <NewBtn />
                            </div>
                        </div>
                    </div>
                </>
            )
        } else {
            location.href = "/"
        }
    } else {
        return (
            <>
                <p className="card-text placeholder-glow">
                    <span className="placeholder col-7"></span>
                    <span className="placeholder col-4"></span>
                    <span className="placeholder col-4"></span>
                    <span className="placeholder col-6"></span>
                    <span className="placeholder col-8"></span>
                </p>
                <p className="card-text placeholder-glow">
                    <span className="placeholder col-7"></span>
                    <span className="placeholder col-4"></span>
                    <span className="placeholder col-4"></span>
                    <span className="placeholder col-6"></span>
                    <span className="placeholder col-8"></span>
                </p>
            </>
        )
    }

}

export default Dashbord
